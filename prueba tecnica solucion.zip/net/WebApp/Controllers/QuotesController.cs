using Microsoft.AspNetCore.Mvc;
using WebApp.Data;

namespace WebApp.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class QuotesController : ControllerBase
    {

        List<QuoteModel> Quotes =
        [
              new () {
      Id = 1,
    Description = "Genius is one percent inspiration and ninety-nine percent perspiration.",
    Author= "Thomas Edison"
  },
  new () {
      Id = 2,
    Description = "You can observe a lot just by watching.",
    Author= "Yogi Berra"
  },
  new () {
      Id = 3,
    Description = "A house divided against itself cannot stand.",
    Author= "Abraham Lincoln"
  },
  new () {
      Id = 4,
    Description = "Difficulties increase the nearer we get to the goal.",
    Author= "Johann Wolfgang von Goethe"
  },
  new () {
      Id = 5,
    Description = "Fate is in your hands and no one elses",
    Author= "Byron Pulsifer"
  },
  new () {
      Id = 6,
    Description = "Be the chief but never the lord.",
    Author= "Lao Tzu"
  },
  new () {
      Id = 7,
    Description = "Nothing happens unless first we dream.",
    Author= "Carl Sandburg"
  },
  new () {
      Id = 8,
    Description = "Well begun is half done.",
    Author= "Aristotle"
  },
  new () {
      Id = 9,
    Description = "Life is a learning experience, only if you learn.",
    Author= "Yogi Berra"
  },
  new () {
      Id = 10,
    Description = "Self-complacency is fatal to progress.",
    Author= "Margaret Sangster"
  },
  new () {
      Id = 11,
    Description = "Peace comes from within. Do not seek it without.",
    Author= "Buddha"
  },
  new () {
      Id = 12,
    Description = "What you give is what you get.",
    Author= "Byron Pulsifer"
  },
  new () {
      Id = 13,
    Description = "We can only learn to love by loving.",
    Author= "Iris Murdoch"
  },
  new () {
      Id = 14,
    Description = "Life is change. Growth is optional. Choose wisely.",
    Author= "Karen Clark"
  },
  new () {
      Id = 15,
    Description = "You'll see it when you believe it.",
    Author= "Wayne Dyer"
  },
  new () {
      Id = 16,
    Description = "Today is the tomorrow we worried about yesterday.",
    Author= null
  },
  new () {
      Id = 17,
    Description = "It's easier to see the mistakes on someone else's paper.",
    Author= null
  },
  new () {
      Id = 18,
    Description = "Every man dies. Not every man really lives.",
    Author= null
  },
  new () {
      Id = 16,
    Description = "To lead people walk behind them.",
    Author= "Lao Tzu"
  }

        ];

        private readonly ILogger<QuotesController> _logger;

        public QuotesController(ILogger<QuotesController> logger)
        {
            _logger = logger;
        }

        [HttpGet()]
        public List<QuoteModel> Get()
        {
            return Quotes;
        }

        [HttpGet("{id}")]
        public QuoteModel? Get(int id)
        {
            return Quotes.FirstOrDefault(x => x.Id == id);
        }

        [HttpGet("filter")]
        public List<QuoteModel> GetByDescription([FromQuery] string description)
        {
            if (string.IsNullOrEmpty(description))
                return Quotes;
            else
                return Quotes.Where(x => x.Description.Contains(description)).ToList();
        }

    }
}
