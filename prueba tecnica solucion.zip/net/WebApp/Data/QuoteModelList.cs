﻿namespace WebApp.Data
{
    public class QuoteModelList
    {
    }
}
